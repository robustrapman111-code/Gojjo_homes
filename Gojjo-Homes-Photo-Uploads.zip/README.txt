GOJJO HOMES — FIRST WEBSITE VERSION

Files:
- index.html — complete responsive website

What is included:
- Professional Gojjo ጎጆ branding
- Custom grass-roof Ethiopian house SVG logo
- Rent / Buy property marketplace layout
- Location + purpose search demo
- Featured property cards
- Property-owner listing form (demo)
- Mobile responsive design

Next production steps:
1. Replace demo property photos/listings with real listings.
2. Connect the listing form to a database/backend.
3. Add user accounts for owners, renters and buyers.
4. Add image uploads and listing approval.
5. Add WhatsApp/phone contact buttons.
6. Deploy with GitHub Pages or another host and connect a custom domain.
